<?php

//-----------------------------------------------------------------------------------------//
//Website Basic Informations
$site_name = 'SK CC Checker';
$site_icon = 'assets/img/Skchk.png';
$owner = 'Hosted by : had3s';

//-----------------------------------------------------------------------------------------//
//API Informations
$api_name[] = 'Stripe API 1 [need SK][Risk: Low]';
$api_file[] = 'Stripe_1.php';

$api_name[] = 'Stripe API 1 [need SK][WebshareProxy Exp]';
$api_file[] = 'Stripe_1_Prox.php';

$api_name[] = 'Stripe API 2 [need SK][Risk: Low]';
$api_file[] = 'Stripe_2.php';

//-----------------------------------------------------------------------------------------//
//Redirect Links
$red_link [] = "https://www.youtube.com/embed/kOHB85vDuow?start=1&autoplay=1";	//Twice - Fancy
$red_link [] = "https://www.youtube.com/embed/mH0_XpSHkZo?start=1&autoplay=1";	//Twice - More & More
$red_link [] = "https://www.youtube.com/embed/mAKsZ26SabQ?start=1&autoplay=1";	//Twice - Yes or Yes
$red_link [] = "https://www.youtube.com/embed/i0p1bmr0EmE?start=1&autoplay=1";	//Twice - What is Love?
$red_link [] = "https://www.youtube.com/embed/rRzxEiBLQCA?start=1&autoplay=1";	//Twice - Heart Shaker
$red_link [] = "https://www.youtube.com/embed/c7rCyll5AeY?start=1&autoplay=1";	//Twice - Cheer Up
$red_link [] = "https://www.youtube.com/embed/0rtV5esQT6I?start=1&autoplay=1";	//Twice - Like OOH-AHH
$red_link [] = "https://www.youtube.com/embed/J_CFBjAyPWE?start=1&autoplay=1";	//Red Velvet - Bad boy
$red_link [] = "https://www.youtube.com/embed/6uJf2IT2Zh8?start=1&autoplay=1";	//Red Velvet - Peek-A-Boo
$red_link [] = "https://www.youtube.com/embed/uR8Mrt1IpXg?start=1&autoplay=1";	//Red Velvet - Psycho
$red_link [] = "https://www.youtube.com/embed/WyiIGEHQP8o?start=1&autoplay=1";	//Red Velvet - Red Flavor
$red_link [] = "https://www.youtube.com/embed/ioNng23DkIM?start=1&autoplay=1";	//BlackPink - How You Like That
$red_link [] = "https://www.youtube.com/embed/2S24-y0Ij3Y?start=1&autoplay=1";	//BlackPink - Kill This Love
$red_link [] = "https://www.youtube.com/embed/IHNzOHi8sJs?start=1&autoplay=1";	//BlackPink - DDU-DU DDU-DU
$red_link [] = "https://www.youtube.com/embed/Amq-qlqbjYA?start=1&autoplay=1";	//BlackPink - As If It's Your Last
$red_link [] = "https://www.youtube.com/embed/fnPn6At3v28?start=1&autoplay=1";	//BlackPink - Sour Candy
$red_link [] = "https://www.youtube.com/embed/vRXZj0DzXIA?start=1&autoplay=1";	//BlackPink - Ice Cream
$red_link [] = "https://www.youtube.com/embed/fE2h3lGlOsk?start=1&autoplay=1";	//Itzy - Wannabe
$red_link [] = "https://www.youtube.com/embed/zndvqTc4P9I?start=1&autoplay=1";	//Itzy - Icy
$red_link [] = "https://www.youtube.com/embed/pNfTK39k55U?start=1&autoplay=1";	//Itzy - Dalla Dalla
$red_link [] = "https://www.youtube.com/embed/wTowEKjDGkU?start=1&autoplay=1";	//Itzy - Not Shy
$red_link [] = "https://www.youtube.com/embed/TgOu00Mf3kI?start=1&autoplay=1";	//IU - _ eight
$red_link [] = "https://www.youtube.com/embed/D1PvIWdJ8xo?start=1&autoplay=1";	//IU - _ Blueming
$red_link [] = "https://www.youtube.com/embed/nM0xDI5R50E?start=1&autoplay=1";	//IU - BBIBBI
$red_link [] = "https://www.youtube.com/embed/d9IxdwEFk1c?start=1&autoplay=1";	//IU - Palette
$red_link [] = "https://www.youtube.com/embed/tDukIfFzX18?start=1&autoplay=1";	//Hwa Sa - _ Maria
$red_link [] = "https://www.youtube.com/embed/lBYyAQ99ZFI?start=1&autoplay=1";	//SOMI - What You Waiting For
$red_link [] = "https://www.youtube.com/embed/gdZLi9oWNZg?start=1&autoplay=1";	//BTS - Dynamite
$red_link [] = "https://www.youtube.com/embed/XsX3ATc3FbA?start=1&autoplay=1";	//BTS - Boy With Luv
$red_link [] = "https://www.youtube.com/embed/MBdVXkSdhwU?start=1&autoplay=1";	//BTS - DNA

//-----------------------------------------------------------------------------------------//
?>